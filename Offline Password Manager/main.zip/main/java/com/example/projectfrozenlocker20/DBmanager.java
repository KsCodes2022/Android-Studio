package com.example.projectfrozenlocker20;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.util.ArrayList;

public class DBmanager extends SQLiteOpenHelper {

    public DBmanager(@Nullable Context context) {
        super(context, "frozenlocker.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, what TEXT NOT NULL, username TEXT NOT NULL, password text NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public Boolean addAccount(Account a){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        String what = Locker.encrypt(a.what);
        String us = Locker.encrypt(a.username);
        String ps = Locker.encrypt(a.password);
        cv.put("what", what);
        cv.put("username", us);
        cv.put("password", ps);
        Log.i("lockerfort", "gg "+what);
        Log.i("lockerfort", "gg "+us);
        Log.i("lockerfort", "gg "+ps);
        long result = db.insert("accounts", null, cv);
        if (result == -1) {
            return false;
        }
        else{
            return true;
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public Boolean updateAccount(Account olda, Account newa){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        newa.what = Locker.encrypt(newa.what);
        newa.username = Locker.encrypt(newa.username);
        newa.password = Locker.encrypt(newa.password);
        cv.put("what", newa.what);
        cv.put("username", newa.username);
        cv.put("password", newa.password);
        long result = db.update("accounts", cv, "id =?", new String[]{Integer.toString(olda.account_id)});
        if (result == -1)
            return false;
        else
            return true;
    }
    public Boolean deleteAccount(Account a){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete("accounts", "id =?", new String[]{Integer.toString(a.account_id)});
        if (result == -1)
            return false;
        else
            return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public ArrayList<Account> retriveAllAccounts(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cr = db.rawQuery("select * from accounts", null);
        ArrayList<Account> list = new ArrayList<Account>();
        while (cr.moveToNext()){
            int id = cr.getInt(0);
            String what = Locker.decrypt(cr.getString(1));
            String us = Locker.decrypt(cr.getString(2));
            String ps = Locker.decrypt(cr.getString(3));
            list.add(new Account(id, what, us, ps));
        }
        return list;
    }


}
