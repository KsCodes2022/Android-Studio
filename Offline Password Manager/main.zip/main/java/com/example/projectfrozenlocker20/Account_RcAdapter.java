package com.example.projectfrozenlocker20;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Account_RcAdapter extends RecyclerView.Adapter<Account_RcAdapter.MyViewHolder>{
    private Activity context;
    public ArrayList<Account> list;
    public DBmanager db;
    private FragmentTransaction fragmentTransaction;
    public Account_RcAdapter(ArrayList<Account> l){
        db = new DBmanager(context);
        this.list = l;
        Log.i("errorsolve", "Account_RcAdapter constructor ="+ list.size());
    }
    public Account_RcAdapter(Activity c, ArrayList<Account> l){
        db = new DBmanager(c);
        context = c;
        list = l;
        Log.i("errorsolve", "Account_RcAdapter constructor with att ="+ list.size());
    }

    public Account_RcAdapter(Activity c, ArrayList<Account> l, FragmentTransaction ft){
        db = new DBmanager(c);
        context = c;
        list = l;
        fragmentTransaction = ft;
        Log.i("errorsolve", "Account_RcAdapter constructor with att ="+ list.size());
    }
    @NonNull

    @Override
    public Account_RcAdapter.MyViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.iteam, parent, false);

        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull  Account_RcAdapter.MyViewHolder holder, int position) {
        Account temp = list.get(position);
        holder.wahtTexV.setText(temp.what);
        holder.usernaemTexV.setText(temp.username);
        int n = temp.password == null? 0 : temp.password.length();
        String str = new String(new char[n]).replace("\0", "*");
        holder.passwordTexV.setText(str);
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Log.i("errorsolve", "in on iteam long click recycle");
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("password", temp.password);
                clipboard.setPrimaryClip(clip);


                Toast.makeText(context,"Password copyed",Toast.LENGTH_SHORT).show();
                return true;
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("errorsolve", "in on iteam click recycle");
                AlertDialog.Builder builder = new AlertDialog.Builder(context);

                //Setting message manually and performing action on button click
                builder.setMessage(" * "+temp.what+"\n * "+temp.username+"\n * "+temp.password)
                        .setCancelable(false)
                        .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                fragmentTransaction.replace(R.id.frm1, new Add_up_fragment("update", temp, context));
                                fragmentTransaction.commit();
                            }
                        })
                        .setNegativeButton("Delete", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                db.deleteAccount(temp);
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setCanceledOnTouchOutside(true);
                alert.setTitle("Details");
                alert.show();
                //Toast.makeText(context,list.get(position).username,Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView wahtTexV;
        TextView usernaemTexV;
        TextView passwordTexV;
        LinearLayout l;
        public MyViewHolder(View view){
            super(view);
            wahtTexV = view.findViewById(R.id.tv_what);
            usernaemTexV = view.findViewById((R.id.tv_username));
            passwordTexV = view.findViewById(R.id.tv_password);
            l = view.findViewById(R.id.rowIteamLinear);
        }
    }
}
