package com.example.projectfrozenlocker20;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


public class Display_accounts_Fragment extends Fragment {
    View view;
    private ArrayList<Account> list= new ArrayList<Account>();
    public DBmanager db;
    public Display_accounts_Fragment(Activity c) {
        db = new DBmanager(c);
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_display_accounts_, container, false);
        buildListData();
        initRecyclerView(view);
        return view;
    }



    private void initRecyclerView(View view) {
        RecyclerView recyclerView = view.findViewById(R.id.recycleView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        Account_RcAdapter adapter = new Account_RcAdapter(getActivity(), list, getActivity().getSupportFragmentManager().beginTransaction());
        recyclerView.setAdapter(adapter);
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    private void buildListData() {
        list = db.retriveAllAccounts();
    }
}