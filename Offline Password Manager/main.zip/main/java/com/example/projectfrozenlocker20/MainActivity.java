package com.example.projectfrozenlocker20;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Locker lk;
    DBmanager dbm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("errorsolve", "in main");
        dbm = new DBmanager(this);
        lk = new Locker();
    }

    public void retrive_all_accounts(View view) {
        String ky = ((EditText) findViewById(R.id.etxt_pass)).getText().toString();
        Locker.setKey(ky);
        Log.i("errorsolve", "in retrive all account");
        replaceFargment(new Display_accounts_Fragment(this));
    }
    public void replaceFargment(Fragment far){
        Log.i("errorsolve", "in replaceFargment");
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frm1, far);
        fragmentTransaction.commit();
        Log.i("errorsolve", "in replaceFargment end");
    }

    public void addNewAccount(View view) {
        replaceFargment(new Add_up_fragment("add", this));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater in = getMenuInflater();
        in.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.about_iteam:
                Intent intent = new Intent(this, About.class);
                startActivity(intent);
                Toast.makeText(this, "About iteam selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.iteam2:
                Toast.makeText(this, "Iteam2 selected", Toast.LENGTH_LONG).show();
                return true;
            case R.id.iteam3:
                Toast.makeText(this, "Iteam3 selected", Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}