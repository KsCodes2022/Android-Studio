package com.example.projectfrozenlocker20;


public class Account {
    public int account_id;
    public String what;
    public String username;
    public String password;

    public Account(){}
    public Account(int acc, String w, String us, String ps){
        account_id = acc;
        what = w;
        username = us;
        password = ps;
    }

}
