package com.example.projectfrozenlocker20;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Add_up_fragment extends Fragment {


    // TODO: Rename and change types of parameters
    private String type;
    private Account acc;
    DBmanager db;

    public Add_up_fragment() {
    }

    public Add_up_fragment(String t, Account a, Activity c) {
        type = t;
        acc = a;
        db = new DBmanager(c);
    }
    public Add_up_fragment(String t, Activity c) {
        type = t;
        db = new DBmanager(c);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_up_fragment, container, false);
        Button add_btn = (Button) view.findViewById(R.id.btn_add);
        Button update_btn = (Button) view.findViewById(R.id.btn_update);
        EditText what = (EditText) view.findViewById(R.id.ad_etxt_waht);
        EditText username = (EditText) view.findViewById(R.id.ad_etxt_username);
        EditText password = (EditText) view.findViewById(R.id.ad_etxt_password);
        if(type == "update"){
            what.setText(acc.what);
            username.setText(acc.username);
            password.setText(acc.password);
            add_btn.setEnabled(false);
            update_btn.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View v) {
                    Account updatedAccount = new Account(
                            acc.account_id,
                            what.getText().toString(),
                            username.getText().toString(),
                            password.getText().toString()
                    );

                    if(db.updateAccount(acc, updatedAccount)){
                        Toast.makeText(getActivity(),"Account Updated sucessfully",Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getActivity(),"Something went wrong",Toast.LENGTH_LONG).show();
                    }
                    Log.i("errorsolve", "added");
                    Log.i("errorsolve", "updated");
                }
            });
        }
        else if(type == "add"){
            update_btn.setEnabled(false);
            add_btn.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                public void onClick(View v) {
                    Account a = new Account(
                            -1,
                            what.getText().toString(),
                            username.getText().toString(),
                            password.getText().toString()
                    );
                    if(db.addAccount(a)){
                        Toast.makeText(getActivity(),"Account Added sucessfully",Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getActivity(),"Something went wrong",Toast.LENGTH_LONG).show();
                    }
                    Log.i("errorsolve", "added");
                }
            });
        }
        return view;
    }
}